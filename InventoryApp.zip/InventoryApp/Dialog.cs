namespace InventoryApp;

public record Field(string Label, string Value = "", string[] Options = null);

public static class Dialog
{
    // Shows a small form with text boxes (or dropdowns when Options is set).
    // Returns the entered values in order, or null if cancelled.
    public static string[] Ask(string title, params Field[] fields)
    {
        using var f = new Form
        {
            Text = title,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            StartPosition = FormStartPosition.CenterParent,
            MaximizeBox = false,
            MinimizeBox = false,
            Font = new Font("Segoe UI", 10f),
            ClientSize = new Size(360, 25 + fields.Length * 40 + 60)
        };

        var inputs = new Control[fields.Length];
        for (int i = 0; i < fields.Length; i++)
        {
            int y = 18 + i * 40;
            f.Controls.Add(new Label { Text = fields[i].Label, Left = 15, Top = y + 4, Width = 115 });

            Control c;
            if (fields[i].Options != null)
            {
                var cb = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
                cb.Items.AddRange(fields[i].Options);
                cb.SelectedItem = fields[i].Value;
                if (cb.SelectedIndex < 0 && cb.Items.Count > 0) cb.SelectedIndex = 0;
                c = cb;
            }
            else c = new TextBox { Text = fields[i].Value };

            c.Left = 135; c.Top = y; c.Width = 210;
            f.Controls.Add(c);
            inputs[i] = c;
        }

        int by = 25 + fields.Length * 40 + 8;
        var ok = new Button { Text = "Save", DialogResult = DialogResult.OK, Left = 175, Top = by, Width = 80, Height = 32 };
        var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Left = 265, Top = by, Width = 80, Height = 32 };
        f.Controls.AddRange(new Control[] { ok, cancel });
        f.AcceptButton = ok; f.CancelButton = cancel;

        return f.ShowDialog() == DialogResult.OK ? inputs.Select(c => c.Text.Trim()).ToArray() : null;
    }
}
