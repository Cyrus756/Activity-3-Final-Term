namespace InventoryApp;

public class LoginForm : Form
{
    readonly TextBox user = new() { Left = 40, Top = 100, Width = 260, PlaceholderText = "Username" };
    readonly TextBox pass = new() { Left = 40, Top = 140, Width = 260, PlaceholderText = "Password", UseSystemPasswordChar = true };

    public LoginForm()
    {
        Text = "Inventory Management System - Login";
        ClientSize = new Size(340, 260);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10f);
        BackColor = Color.FromArgb(240, 244, 250);

        var title = new Label
        {
            Text = "Inventory Login",
            Font = new Font("Segoe UI", 18f, FontStyle.Bold),
            ForeColor = Color.FromArgb(15, 45, 90),
            AutoSize = true, Left = 40, Top = 35
        };
        var hint = new Label { Text = "Default: admin / admin123", ForeColor = Color.Gray, AutoSize = true, Left = 40, Top = 70 };
        var btn = new Button
        {
            Text = "Login", Left = 40, Top = 190, Width = 260, Height = 38,
            FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(25, 105, 215), ForeColor = Color.White
        };
        btn.FlatAppearance.BorderSize = 0;
        btn.Click += (s, e) =>
        {
            if (user.Text == "admin" && pass.Text == "admin123") DialogResult = DialogResult.OK;
            else MessageBox.Show("Invalid username or password.", "Login failed");
        };
        AcceptButton = btn;
        Controls.AddRange(new Control[] { title, hint, user, pass, btn });
    }
}
