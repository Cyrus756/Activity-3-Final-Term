using System.Text.Json;

namespace InventoryApp;

// Simple JSON file storage (inventory.json next to the .exe). No database setup needed.
public static class DataStore
{
    static readonly string FilePath = Path.Combine(AppContext.BaseDirectory, "inventory.json");

    public static List<Category> Categories = new();
    public static List<Supplier> Suppliers = new();
    public static List<Product> Products = new();

    class Db
    {
        public List<Category> Categories { get; set; } = new();
        public List<Supplier> Suppliers { get; set; } = new();
        public List<Product> Products { get; set; } = new();
    }

    public static void Load()
    {
        if (File.Exists(FilePath))
        {
            try
            {
                var db = JsonSerializer.Deserialize<Db>(File.ReadAllText(FilePath));
                Categories = db.Categories; Suppliers = db.Suppliers; Products = db.Products;
                return;
            }
            catch { /* corrupted file: fall through and reseed */ }
        }
        Seed();
        Save();
    }

    public static void Save()
    {
        var db = new Db { Categories = Categories, Suppliers = Suppliers, Products = Products };
        File.WriteAllText(FilePath, JsonSerializer.Serialize(db, new JsonSerializerOptions { WriteIndented = true }));
    }

    public static int NextId(IEnumerable<int> ids) => ids.DefaultIfEmpty(0).Max() + 1;
    public static string CategoryName(int id) => Categories.FirstOrDefault(c => c.Id == id)?.Name ?? "-";
    public static string SupplierName(int id) => Suppliers.FirstOrDefault(s => s.Id == id)?.Name ?? "-";

    static void Seed()
    {
        string[] cats = { "Electronics", "Office Supplies", "Furniture", "Accessories", "Packaging" };
        for (int i = 0; i < cats.Length; i++) Categories.Add(new Category { Id = i + 1, Name = cats[i] });

        Suppliers.Add(new Supplier { Id = 1, Name = "TechSource Ltd", Phone = "555-0101", Email = "sales@techsource.com" });
        Suppliers.Add(new Supplier { Id = 2, Name = "OfficePro", Phone = "555-0102", Email = "info@officepro.com" });
        Suppliers.Add(new Supplier { Id = 3, Name = "HomeWorks", Phone = "555-0103", Email = "orders@homeworks.com" });

        Products.Add(new Product { Id = 1, Name = "Wireless Mouse", CategoryId = 1, SupplierId = 1, Price = 15.99m, Quantity = 40 });
        Products.Add(new Product { Id = 2, Name = "Keyboard", CategoryId = 1, SupplierId = 1, Price = 29.50m, Quantity = 6 });
        Products.Add(new Product { Id = 3, Name = "A4 Paper (500)", CategoryId = 2, SupplierId = 2, Price = 6.25m, Quantity = 120 });
        Products.Add(new Product { Id = 4, Name = "Office Chair", CategoryId = 3, SupplierId = 3, Price = 89.00m, Quantity = 4 });
        Products.Add(new Product { Id = 5, Name = "USB Cable", CategoryId = 4, SupplierId = 1, Price = 4.99m, Quantity = 60 });
    }
}
