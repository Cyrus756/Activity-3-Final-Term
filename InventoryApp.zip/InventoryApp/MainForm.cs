namespace InventoryApp;

public class MainForm : Form
{
    static readonly Color SidebarColor = Color.FromArgb(15, 45, 90);
    static readonly Color ActiveColor = Color.FromArgb(25, 105, 215);
    static readonly Color PageBg = Color.FromArgb(240, 244, 250);
    static readonly Color Blue = Color.FromArgb(37, 99, 235);
    static readonly Color Green = Color.FromArgb(22, 163, 74);
    static readonly Color Orange = Color.FromArgb(245, 158, 30);
    static readonly Color Purple = Color.FromArgb(109, 72, 200);
    static readonly Color Teal = Color.FromArgb(13, 148, 136);
    static readonly Color Red = Color.FromArgb(220, 53, 69);

    readonly Panel content = new() { Dock = DockStyle.Fill, BackColor = PageBg, Padding = new Padding(24) };
    readonly Dictionary<string, Button> nav = new();
    public bool LoggedOut;

    public MainForm()
    {
        Text = "Dashboard - Inventory Management System";
        Size = new Size(1000, 640);
        MinimumSize = new Size(860, 560);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10f);

        var sidebar = new Panel { Dock = DockStyle.Left, Width = 190, BackColor = SidebarColor };

        var logout = NavButton("Logout");
        logout.Dock = DockStyle.Bottom;
        logout.Click += (s, e) => { LoggedOut = true; Close(); };
        sidebar.Controls.Add(logout);

        // Docked-top controls stack in reverse order of adding
        foreach (var name in new[] { "Reports", "Suppliers", "Categories", "Products", "Dashboard" })
        {
            var b = NavButton(name);
            b.Dock = DockStyle.Top;
            b.Click += (s, e) => Navigate(name);
            nav[name] = b;
            sidebar.Controls.Add(b);
        }

        Controls.Add(content);
        Controls.Add(sidebar);
        Navigate("Dashboard");
    }

    Button NavButton(string text)
    {
        var b = new Button
        {
            Text = "   " + text, Height = 48,
            FlatStyle = FlatStyle.Flat, BackColor = SidebarColor, ForeColor = Color.White,
            TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 11f),
            Cursor = Cursors.Hand
        };
        b.FlatAppearance.BorderSize = 0;
        return b;
    }

    public void Navigate(string page)
    {
        foreach (var kv in nav) kv.Value.BackColor = kv.Key == page ? ActiveColor : SidebarColor;

        content.SuspendLayout();
        content.Controls.Clear();
        Control view = page switch
        {
            "Products" => ProductsView(),
            "Categories" => CategoriesView(),
            "Suppliers" => SuppliersView(),
            "Reports" => ReportsView(),
            _ => DashboardView()
        };
        view.Dock = DockStyle.Fill;
        content.Controls.Add(view);
        content.ResumeLayout();
    }

    // ---------- Dashboard ----------
    Control DashboardView()
    {
        var root = new TableLayoutPanel { ColumnCount = 1, RowCount = 4 };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 130));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        root.Controls.Add(new Label
        {
            Text = "Welcome, Admin!", Font = new Font("Segoe UI", 20f, FontStyle.Bold),
            AutoSize = true, Margin = new Padding(0)
        }, 0, 0);
        root.Controls.Add(new Label
        {
            Text = "Inventory Management System", ForeColor = Color.Gray,
            Font = new Font("Segoe UI", 11f), AutoSize = true, Margin = new Padding(0, 0, 0, 8)
        }, 0, 1);

        int low = DataStore.Products.Count(p => p.IsLow);
        var cards = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 1, Margin = new Padding(0, 8, 0, 12) };
        for (int i = 0; i < 4; i++) cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        cards.Controls.Add(Card("Total Products", DataStore.Products.Count.ToString(), Blue, "Products"), 0, 0);
        cards.Controls.Add(Card("Categories", DataStore.Categories.Count.ToString(), Green, "Categories"), 1, 0);
        cards.Controls.Add(Card("Suppliers", DataStore.Suppliers.Count.ToString(), Orange, "Suppliers"), 2, 0);
        cards.Controls.Add(Card("Low Stock", low.ToString(), Purple, "Reports"), 3, 0);
        root.Controls.Add(cards, 0, 2);

        var quick = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(16) };
        var actions = new TableLayoutPanel { Dock = DockStyle.Top, Height = 120, ColumnCount = 4, RowCount = 1 };
        for (int i = 0; i < 4; i++) actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        actions.Controls.Add(ActionButton("Add Product", Green, () => { ProductDialog(null); Navigate("Dashboard"); }), 0, 0);
        actions.Controls.Add(ActionButton("View Products", Blue, () => Navigate("Products")), 1, 0);
        actions.Controls.Add(ActionButton("Manage Categories", Purple, () => Navigate("Categories")), 2, 0);
        actions.Controls.Add(ActionButton("Manage Suppliers", Teal, () => Navigate("Suppliers")), 3, 0);
        quick.Controls.Add(actions);
        quick.Controls.Add(new Label
        {
            Text = "Quick Actions", Font = new Font("Segoe UI", 12f, FontStyle.Bold),
            Dock = DockStyle.Top, Height = 36
        });
        root.Controls.Add(quick, 0, 3);
        return root;
    }

    Control Card(string title, string value, Color color, string page)
    {
        var p = new Panel { BackColor = color, Dock = DockStyle.Fill, Margin = new Padding(0, 0, 12, 0), Cursor = Cursors.Hand };
        var v = new Label
        {
            Text = value, Font = new Font("Segoe UI", 22f, FontStyle.Bold), ForeColor = Color.White,
            Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter
        };
        var t = new Label
        {
            Text = title, Font = new Font("Segoe UI", 11f, FontStyle.Bold), ForeColor = Color.White,
            Dock = DockStyle.Top, Height = 44, TextAlign = ContentAlignment.BottomCenter
        };
        p.Controls.Add(v);
        p.Controls.Add(t);
        EventHandler go = (s, e) => Navigate(page);
        p.Click += go; v.Click += go; t.Click += go;
        return p;
    }

    Button ActionButton(string text, Color color, Action onClick)
    {
        var b = new Button
        {
            Text = text, Dock = DockStyle.Fill, Margin = new Padding(0, 0, 12, 0),
            FlatStyle = FlatStyle.Flat, BackColor = color, ForeColor = Color.White,
            Font = new Font("Segoe UI", 11f, FontStyle.Bold), Cursor = Cursors.Hand
        };
        b.FlatAppearance.BorderSize = 0;
        b.Click += (s, e) => onClick();
        return b;
    }

    // ---------- Generic list page with Add / Edit / Delete ----------
    Control CrudView(string title, string noun, Func<string, object> rows, Action add, Action<int> edit, Action<int> delete)
    {
        var root = new Panel();
        var grid = MakeGrid();
        var header = new Label { Text = title, Font = new Font("Segoe UI", 18f, FontStyle.Bold), Dock = DockStyle.Top, Height = 46 };
        var bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 50 };
        var search = new TextBox { Width = 220, PlaceholderText = "Search...", Margin = new Padding(0, 6, 12, 0) };

        void Bind() => grid.DataSource = rows(search.Text.Trim());
        search.TextChanged += (s, e) => Bind();

        var addB = SmallButton("Add " + noun, Green, () => { add(); Bind(); });
        var editB = SmallButton("Edit", Blue, () =>
        {
            if (SelectedId(grid) is int id) { edit(id); Bind(); }
        });
        var delB = SmallButton("Delete", Red, () =>
        {
            if (SelectedId(grid) is int id &&
                MessageBox.Show($"Delete this {noun.ToLower()}?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                delete(id); Bind();
            }
        });
        bar.Controls.AddRange(new Control[] { search, addB, editB, delB });

        root.Controls.Add(grid);
        root.Controls.Add(bar);
        root.Controls.Add(header);
        Bind();
        return root;
    }

    Button SmallButton(string text, Color color, Action onClick)
    {
        var b = new Button
        {
            Text = text, AutoSize = true, MinimumSize = new Size(90, 34), Margin = new Padding(0, 4, 8, 0),
            FlatStyle = FlatStyle.Flat, BackColor = color, ForeColor = Color.White, Cursor = Cursors.Hand
        };
        b.FlatAppearance.BorderSize = 0;
        b.Click += (s, e) => onClick();
        return b;
    }

    DataGridView MakeGrid()
    {
        var g = new DataGridView
        {
            Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, BackgroundColor = Color.White,
            RowHeadersVisible = false, BorderStyle = BorderStyle.None, EnableHeadersVisualStyles = false
        };
        g.ColumnHeadersDefaultCellStyle.BackColor = SidebarColor;
        g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        g.ColumnHeadersDefaultCellStyle.SelectionBackColor = SidebarColor;
        g.ColumnHeadersHeight = 36;
        g.DataBindingComplete += (s, e) => { if (g.Columns["Id"] != null) g.Columns["Id"].Visible = false; };
        return g;
    }

    static int? SelectedId(DataGridView g) =>
        g.CurrentRow == null ? null : Convert.ToInt32(g.CurrentRow.Cells["Id"].Value);

    static bool Has(string text, string q) => q == "" || (text ?? "").Contains(q, StringComparison.OrdinalIgnoreCase);

    // ---------- Products ----------
    Control ProductsView() => CrudView("Products", "Product",
        q => ProductRepo.GetAll()
            .Where(p => Has(p.Name, q) || Has(DataStore.CategoryName(p.CategoryId), q) || Has(DataStore.SupplierName(p.SupplierId), q))
            .Select(p => new
            {
                p.Id, p.Name,
                Category = DataStore.CategoryName(p.CategoryId),
                Supplier = DataStore.SupplierName(p.SupplierId),
                p.Price, p.Quantity,
                Status = p.IsLow ? "Low Stock" : "In Stock"
            }).ToList(),
        () => ProductDialog(null),
        id => ProductDialog(ProductRepo.GetById(id)),
        id => ProductRepo.Delete(id));

    void ProductDialog(Product p)
    {
        if (!DataStore.Categories.Any() || !DataStore.Suppliers.Any())
        {
            MessageBox.Show("Add at least one category and one supplier first.");
            return;
        }
        bool isNew = p == null;
        var cats = DataStore.Categories.Select(c => c.Name).ToArray();
        var sups = DataStore.Suppliers.Select(s => s.Name).ToArray();

        var r = Dialog.Ask(isNew ? "Add Product" : "Edit Product",
            new Field("Name", p?.Name ?? ""),
            new Field("Category", isNew ? "" : DataStore.CategoryName(p.CategoryId), cats),
            new Field("Supplier", isNew ? "" : DataStore.SupplierName(p.SupplierId), sups),
            new Field("Price", isNew ? "0.00" : p.Price.ToString("0.00")),
            new Field("Quantity", isNew ? "0" : p.Quantity.ToString()),
            new Field("Reorder level", isNew ? "10" : p.ReorderLevel.ToString()));
        if (r == null) return;

        if (string.IsNullOrWhiteSpace(r[0]) || !decimal.TryParse(r[3], out var price) ||
            !int.TryParse(r[4], out var qty) || !int.TryParse(r[5], out var reorder) || price < 0 || qty < 0)
        {
            MessageBox.Show("Please enter a name and valid numbers.");
            return;
        }

        p ??= new Product();
        p.Name = r[0];
        p.CategoryId = DataStore.Categories.First(c => c.Name == r[1]).Id;
        p.SupplierId = DataStore.Suppliers.First(s => s.Name == r[2]).Id;
        p.Price = price; p.Quantity = qty; p.ReorderLevel = reorder;
        if (isNew) ProductRepo.Create(p);
        else ProductRepo.Update(p);
    }

    // ---------- Categories ----------
    Control CategoriesView() => CrudView("Categories", "Category",
        q => CategoryRepo.GetAll().Where(c => Has(c.Name, q))
            .Select(c => new { c.Id, c.Name, Products = DataStore.Products.Count(p => p.CategoryId == c.Id) }).ToList(),
        () =>
        {
            var r = Dialog.Ask("Add Category", new Field("Name"));
            if (r == null || r[0] == "") return;
            CategoryRepo.Create(new Category { Name = r[0] });
        },
        id =>
        {
            var c = CategoryRepo.GetById(id);
            var r = Dialog.Ask("Edit Category", new Field("Name", c.Name));
            if (r == null || r[0] == "") return;
            c.Name = r[0];
            CategoryRepo.Update(c);
        },
        id =>
        {
            if (!CategoryRepo.Delete(id))
                MessageBox.Show("This category still has products. Move or delete them first.");
        });

    // ---------- Suppliers ----------
    Control SuppliersView() => CrudView("Suppliers", "Supplier",
        q => SupplierRepo.GetAll().Where(s => Has(s.Name, q) || Has(s.Email, q))
            .Select(s => new { s.Id, s.Name, s.Phone, s.Email, Products = DataStore.Products.Count(p => p.SupplierId == s.Id) }).ToList(),
        () => SupplierDialog(null),
        id => SupplierDialog(SupplierRepo.GetById(id)),
        id =>
        {
            if (!SupplierRepo.Delete(id))
                MessageBox.Show("This supplier still has products. Reassign or delete them first.");
        });

    void SupplierDialog(Supplier s)
    {
        bool isNew = s == null;
        var r = Dialog.Ask(isNew ? "Add Supplier" : "Edit Supplier",
            new Field("Name", s?.Name ?? ""), new Field("Phone", s?.Phone ?? ""), new Field("Email", s?.Email ?? ""));
        if (r == null || r[0] == "") return;
        s ??= new Supplier();
        s.Name = r[0]; s.Phone = r[1]; s.Email = r[2];
        if (isNew) SupplierRepo.Create(s);
        else SupplierRepo.Update(s);
    }

    // ---------- Reports ----------
    Control ReportsView()
    {
        var root = new Panel();
        var grid = MakeGrid();
        var low = DataStore.Products.Where(p => p.IsLow).ToList();
        grid.DataSource = low.Select(p => new
        {
            p.Id, p.Name,
            Category = DataStore.CategoryName(p.CategoryId),
            Supplier = DataStore.SupplierName(p.SupplierId),
            p.Quantity, p.ReorderLevel
        }).ToList();

        decimal value = DataStore.Products.Sum(p => p.Price * p.Quantity);
        int units = DataStore.Products.Sum(p => p.Quantity);

        var sub = new Label
        {
            Text = "Low stock items", Font = new Font("Segoe UI", 12f, FontStyle.Bold),
            Dock = DockStyle.Top, Height = 36, TextAlign = ContentAlignment.BottomLeft
        };
        var summary = new Label
        {
            Text = $"Total stock value: {value:C}     Units in stock: {units}     Low-stock items: {low.Count}",
            Dock = DockStyle.Top, Height = 34, ForeColor = Color.FromArgb(60, 60, 60)
        };
        var header = new Label { Text = "Reports", Font = new Font("Segoe UI", 18f, FontStyle.Bold), Dock = DockStyle.Top, Height = 46 };

        root.Controls.Add(grid);
        root.Controls.Add(sub);
        root.Controls.Add(summary);
        root.Controls.Add(header);
        return root;
    }
}
