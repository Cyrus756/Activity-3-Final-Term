namespace InventoryApp;

public class Category
{
    public int Id { get; set; }
    public string Name { get; set; }
}

public class Supplier
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Phone { get; set; }
    public string Email { get; set; }
}

public class Product
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int CategoryId { get; set; }
    public int SupplierId { get; set; }
    public decimal Price { get; set; }
    public int Quantity { get; set; }
    public int ReorderLevel { get; set; } = 10;
    public bool IsLow => Quantity <= ReorderLevel;
}
