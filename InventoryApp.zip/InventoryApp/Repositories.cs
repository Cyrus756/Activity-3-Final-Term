namespace InventoryApp;

// CRUD layer: Create, Read (GetAll / GetById), Update, Delete for each table.
// The forms only talk to these methods, never to the lists directly.

public static class ProductRepo
{
    // CREATE
    public static void Create(Product p)
    {
        p.Id = DataStore.NextId(DataStore.Products.Select(x => x.Id));
        DataStore.Products.Add(p);
        DataStore.Save();
    }

    // READ
    public static List<Product> GetAll() => DataStore.Products.ToList();
    public static Product GetById(int id) => DataStore.Products.FirstOrDefault(x => x.Id == id);

    // UPDATE
    public static bool Update(Product p)
    {
        int i = DataStore.Products.FindIndex(x => x.Id == p.Id);
        if (i < 0) return false;
        DataStore.Products[i] = p;
        DataStore.Save();
        return true;
    }

    // DELETE
    public static bool Delete(int id)
    {
        bool removed = DataStore.Products.RemoveAll(x => x.Id == id) > 0;
        if (removed) DataStore.Save();
        return removed;
    }
}

public static class CategoryRepo
{
    public static void Create(Category c)
    {
        c.Id = DataStore.NextId(DataStore.Categories.Select(x => x.Id));
        DataStore.Categories.Add(c);
        DataStore.Save();
    }

    public static List<Category> GetAll() => DataStore.Categories.ToList();
    public static Category GetById(int id) => DataStore.Categories.FirstOrDefault(x => x.Id == id);

    public static bool Update(Category c)
    {
        int i = DataStore.Categories.FindIndex(x => x.Id == c.Id);
        if (i < 0) return false;
        DataStore.Categories[i] = c;
        DataStore.Save();
        return true;
    }

    public static bool InUse(int id) => DataStore.Products.Any(p => p.CategoryId == id);

    public static bool Delete(int id)
    {
        if (InUse(id)) return false;
        bool removed = DataStore.Categories.RemoveAll(x => x.Id == id) > 0;
        if (removed) DataStore.Save();
        return removed;
    }
}

public static class SupplierRepo
{
    public static void Create(Supplier s)
    {
        s.Id = DataStore.NextId(DataStore.Suppliers.Select(x => x.Id));
        DataStore.Suppliers.Add(s);
        DataStore.Save();
    }

    public static List<Supplier> GetAll() => DataStore.Suppliers.ToList();
    public static Supplier GetById(int id) => DataStore.Suppliers.FirstOrDefault(x => x.Id == id);

    public static bool Update(Supplier s)
    {
        int i = DataStore.Suppliers.FindIndex(x => x.Id == s.Id);
        if (i < 0) return false;
        DataStore.Suppliers[i] = s;
        DataStore.Save();
        return true;
    }

    public static bool InUse(int id) => DataStore.Products.Any(p => p.SupplierId == id);

    public static bool Delete(int id)
    {
        if (InUse(id)) return false;
        bool removed = DataStore.Suppliers.RemoveAll(x => x.Id == id) > 0;
        if (removed) DataStore.Save();
        return removed;
    }
}
